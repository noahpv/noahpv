function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(0);
}
function setup() {
  createCanvas(100, 100, WEBGL);

  describe('A row of white cubes on a gray background.');
}

function draw() {
  background(200);

  // Apply the default frustum projection.
  frustum();

  // Translate the origin toward the camera.
  translate(-10, 10, 600);

  // Rotate the coordinate system.
  rotateY(-0.1);
  rotateX(-0.1);

  // Draw the row of boxes.
  for (let i = 0; i < 6; i += 1) {
    translate(0, 0, -40);
    box(10);
  }
}
